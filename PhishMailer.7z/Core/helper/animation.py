import time 
import sys
import os

red = ("\033[1;31;40m")
green = ("\033[1;32;40m")
white = ("\033[1;37;40m")
blue = ("\033[1;34;40m")
yellow = ("\033[1;33;40m")
start = (green + "[" + white + "+" + green + "]" + white)
alert = (green + "[" + red + "!" + green + "]" + white)
question = (green + "[" + yellow + "?" + green + "]" + white)


def AnimationMain():
	SeenCheck = open("Core/IntroSeen.txt", "r")
	Check = SeenCheck.read()
	SeenCheck.close()
	if "Yes" in Check:
		pass
	else:
		os.system("clear")
		IntroSeen = open("Core/IntroSeen.txt", "w+")
		IntroSeen.write("Yes")
		IntroSeen.close()

		print(blue + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" + white + "|" + blue + "~~~")
		time.sleep(0.1)
		print(white + " PhishMailer Version 2.0     .                     .              |")
		time.sleep(0.1)
		print(" Instagram: bizk3n           .                     .              |")
		time.sleep(0.1)
		print(" bizken@protonmail.com        . " + green + " /                " + white + " .  " + blue + " ___ " + white + "       |")
		time.sleep(0.1)
		print(green + "                              . /--\ /     " + blue + "           /   \ " + white + "      |")
		time.sleep(0.1)
		print("           ." + green + "                   <o)  =< " + blue + "              /     \    " + red + "  J")
		time.sleep(0.1)
		print(white + "          .                     " + green + "\__/ \ " + blue + "             (__O_O__)")
		time.sleep(0.1)
		print(yellow + "  |  |" + white + "    ." + green + "                        \ " + blue + "                 |||||")
		time.sleep(0.1)
		print(yellow + "   \/        Y " + green + "         ) " + blue + "                            |||||")
		time.sleep(0.1)
		print(yellow + "   |  /!-!\  | " + green + "        ( " + blue + "                          \_///| \\__/")
		time.sleep(0.1)
		print(yellow + "    \|     |/  " + green + "         ) " + blue + "                          _// |  \_")
		time.sleep(0.1)
		print(yellow + "     _\___/_ " + green + "           (   ( " + blue + "                         / /")
		time.sleep(0.1)
		print(yellow + "    / /   \ \ " + green + "           )   ) ")
		time.sleep(0.1)
		print(white + "^^^^^^^^^^^^^^^^\ " + green + "      (   ( ")
		time.sleep(0.1)
		print(white + "                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\                /^^")
		time.sleep(0.1)
		print("                                                   ^^^^^^^^^^^^^^^^ ")


		lines = [green + " PhishMailer 2.0 Yeni Büyük Güncelleme!",
				white + " PhishMailer'da Yeni Olanlar İçin Sadece Hoş Geldiniz demek istiyorum! \n", 
				alert + " Yeni Güncelleme Hakkında Hızlı Bilgi:",
				start + " Posta Bölümünde Bir Temizleme Yaptı \n",
				start + " Artık E-postalarınızı Daha Hızlı ve Daha Kolay Kullanım İçin Kaydedebilirsiniz \n",
				start + " Ayrıca Gönderenin Adını Başka Birinden Gelmiş Gibi Görünecek Şekilde Değiştirebilirsiniz \n",
				start + " Gelen Her Yeni Güncelleme İçin Bu Bilgi Çıktısını Göreceksiniz Ama Sadece Bunları Göreceksiniz",
				"    PhishMailer'i İlk Defa Çalıştırdığınızda \n",
				start + " Bazı Bölgelerde Kodu Çok Değiştirdi \n",
				start + " PhishMailer'ın Nasıl Kullanılacağına Dair Video Eğitimleri Üzerinde Çalışmak \n",
				start + " Bunu Okursanız Bu, PhishMailer'ın Nasıl Kullanılacağına İlişkin Öğreticilerle Henüz Wiki'yi Yayınlamadığım Anlamına Gelir \n",
				"    Çok Yakında Gelecek, Önce Bitirmem Gerekiyor \n",
				question + " Sonraki Güncellemede Neler Oluyor? \n",
				start + " Şu Anda SMTP Üzerinde Çalışıyorum, Böylece Oltalama Saldırıları Sahtecilik gibi Daha Yasal Görünüyor",
				start + " Daha Fazla Şablon Ekle (Fikirler için DM Ve Ne Yapabileceğimi Görebiliyorum) \n",
				start + " Bunun İçin Toplu Gönderici ve Şablonlar Oluşturun \n",
				alert + " Her Güncelleme İçin Daha Fazlası Gelecek! \n",
				start + " Sorularınız Varsa Instagram'da En Aktifim: bizk3n Bilmek İstediğiniz veya Fikriniz Varsa Dm Gönderin\n",
				start + " Mutlu Kimlik Avları -BiZken , Bürküt"]
				
		for line in lines:         
			for c in line:          
				print(c, end='')    
				sys.stdout.flush()  
				time.sleep(0.05)          
			print('') 





