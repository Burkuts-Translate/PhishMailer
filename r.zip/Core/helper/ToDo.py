import os
import sys
from .color import green, white, blue, start, alert, numbering

def TODO():
	print(start + " Yapılacaklar Listesi " + start)
	print(alert + " Bu Liste Güncellenecek" + alert)
	print("")
	print(numbering(1) + white + " Daha Fazla E-posta Şablonu Ekle (her zaman güncellenir)" + numbering(1))
	print(numbering(2) + white + " Daha İyi Arayüz Oluşturun (biraz zaman alabilir) " + numbering(2))
	print(numbering(3) + white + " Toplu E-posta Göndericisi Ekle " + numbering(3))
	print(numbering(4) + white + " Farklı Dillerde E-posta Ekleyin " + numbering(4))
	print(numbering(5) + white + " Daha Fazla Hedef Belirtilmiş E-posta Ekle " + numbering(5))
	print(numbering(7) + white + " Daha Fazla Bypass Yöntemi Ekle " + numbering(6))
	

