import smtplib
import os
import getpass
import sys
import ssl
import time
from email.mime.text import MIMEText
from email.utils import formataddr
from email.mime.multipart import MIMEMultipart  
from email.mime.base import MIMEBase  
from email import encoders  
from email.mime.text import MIMEText

red = ("\033[1;31;40m")
green = ("\033[1;32;40m")
white = ("\033[1;37;40m")
blue = ("\033[1;34;40m")
yellow = ("\033[1;33;40m")
start = (green + "[" + white + "+" + green + "]" + white)
alert = (green + "[" + red + "!" + green + "]" + white)
question = (green + "[" + yellow + "?" + green + "]" + white)


def numbering(num):
  return green + "[" + white + str(num) + green + "]"

def MailingMain():
	os.system("clear")
	print(green)
	print("""
	 __^__                                                        __^__
	( ___ )------------------------------------------------------( ___ )
	 | / |                                                        | \ |
	 | / |+------------)PhishMailer BaitMailer V2.0(-------------+| \ |
	 |___|                                                        |___|
	(_____)------------------------------------------------------(_____) """)

	print(alert + "Hedef E-postayı Alıncaya Kadar Birkaç Dakika Alabilir" + alert)
	print(alert + "E-posta Hesabınızda Daha Az Güvenli Uygulamalara İzin Vermeniz Gerekebilir" + alert)
		
	print("")
	fromaddr = input(start + " E-posta adresinizi giriniz: ")
	password = input(start + " Şifrenizi girin: ")
	FakeName = input(start + " Hedefin Görmesini İstediğiniz Adı ​​Belirleyin (ör. Instagram Hesap Güvenliği)")	
	toaddr = input(start + " Gönderilecek E-posta Adresini Girin: ")
	subject = input(start + " Konu Girin: ")
	pathfile = input(start + " Html Dosyasının Yolunu Girin: ")
	
	html = open(pathfile)
	msg = MIMEText(html.read(), 'html')
	msg['From'] = FakeName
	msg['To'] = toaddr
	msg['Subject'] = subject

	if "@gmail" in fromaddr:
		print("gmail")
		time.sleep(5)
		debug = False
		if debug:
			print(msg.as_string())
		else:
			server = smtplib.SMTP('smtp.gmail.com',587)
			server.starttls()
			server.login(fromaddr, password)
			text = msg.as_string()
			server.sendmail(fromaddr, toaddr, text)
			server.quit()
			print(alert + "E-posta gönderildi" + alert)

	elif "@hotmail" in fromaddr or "@outlook" in fromaddr or "@live" in fromaddr:
		print("live")
		time.sleep(5)
		debug = False
		if debug:
			print(msg.as_string())
		else:
			server = smtplib.SMTP('smtp.live.com',587)
			server.starttls()
			server.login(fromaddr, password)
			text = msg.as_string()
			server.sendmail(fromaddr, toaddr, text)
			server.quit()
			print(alert + "E-posta gönderildi" + alert)
			
	elif "@yahoo" in fromaddr:
		print("yahoo")
		time.sleep(5)
		debug = False
		if debug:
			print(msg.as_string())
		else:
			server = smtplib.SMTP_SSL('smtp.mail.yahoo.com',465)
			server.starttls()
			server.login(fromaddr, password)
			text = msg.as_string()
			server.sendmail(fromaddr, toaddr, text)
			server.quit()
			print(alert + "E-posta gönderildi" + alert)
			
	else:
		print(alert + " Henüz o e-posta sağlayıcısını desteklemiyor")
		print(question + " Özel SMTP Yakında Gelecek")

def accountsave():
	print(green)

	print("       ,   ,")
	print("      /////|")
	print("     ///// |")
	print("    /////  |")
	print("   |~~~| | |")
	print("   |===| |/|")
	print("   |" + white + " S " + green + "|/| |")
	print("   |" + white + " A " + green + "| | |")
	print("   |" + white + " V " + green + "| | |")
	print("   |" + white + " E " + green + "|  /")
	print("   |" + white + " D " + green + "| /")
	print("   |===|/")
	print("   '---'")
	print("")
	
	Email = input(start + " Kaydetmek için E-postayı Girin: " + green)
	os.system("clear")
	print(alert + " Seçilen E-posta: " + red + Email + "\n")

	passwd = input(start + " Kaydetmek için Şifreyi Girin: " + green)
	os.system("clear") 
	print("\n" + alert + " Seçilen E-posta: " + yellow + Email + "\n")
	print(alert + " Seçilen Şifre: " + yellow + passwd + "\n")
	print(question + "Bilgiler Doğru mu? \n")
	
	Correct = input(yellow + "BoatMaking@Phishmailer:~ [Y or N]: " + white)
	
	if Correct == "N" or Correct == "n":
		accountsave()
		
	elif Correct == "Y":
		with open("emails.txt", 'a') as f:
			f.write(Email + "\n")
			f.close
	
		with open("passwords.txt", "a") as f:
			f.write(passwd + "\n")
			f.close
		
		print(start + " Email Kayıt Edildi")
		time.sleep(2.5)
		os.system("clear")
		pick()
	
	else:
		print(alert + " Hata")


def pick():	
	os.system("clear")
	file1 = open("emails.txt", "r")
	lines = file1.readlines()
	print(start + green + " Kayıtlı E-postalar")
	print(green + "Ayarlar:" + white)
	count = 0
	for line in lines:
		count += 1
		print("[{}]: {} \n".format(count, line.strip()))
	
	print(numbering(99) + white + " Bir Kez Başka E-posta Kullan")
	print(numbering(666) + white + " Başka Bir E-posta Kaydet")
	
	line_number = int(input(start + " ----> "))
	
	if line_number == 99:
		MailingMain()
	
	elif line_number == 666:
		accountsave()	
	
	else:	
		UsernameListed = (line_number - 1)
		passwordlisted = (line_number - 1)
		
		with open("emails.txt") as fobj:
			data = fobj.read()
			lines = data.split("\n")
			fromaddr = lines[UsernameListed]
			
		with open("passwords.txt") as fobj:
			data = fobj.read()
			lines = data.split("\n")
			password = lines[passwordlisted]
		
		FakeName = input(start + " Hedefin Görmesini İstediğiniz Adı ​​Belirleyin (ör. Instagram Hesap Güvenliği)")	
		toaddr = input(start + " Gönderilecek E-posta Adresini Girin: ")
		subject = input(start + " Konu Girin: ")
		pathfile = input(start + " Html Dosyasının Yolunu Girin: ")
		
		html = open(pathfile)
		msg = MIMEText(html.read(), 'html')
		msg['From'] = FakeName
		msg['To'] = toaddr
		msg['Subject'] = subject

		if "@gmail" in fromaddr:
			print("gmail")
			time.sleep(5)
			debug = False
			if debug:
				print(msg.as_string())
			else:
				server = smtplib.SMTP('smtp.gmail.com',587)
				server.starttls()
				server.login(fromaddr, password)
				text = msg.as_string()
				server.sendmail(fromaddr, toaddr, text)
				server.quit()
				print(alert + "Email Gönderildi" + alert)
					
				PermCheck = open("Permission.txt", "r")
				Check = PermCheck.read()
				PermCheck.close()
				while True:
						if "Yes" in Check:
							subject = "Phishmailer Sender"
							text = "Email Sent With PhishMailer"
							message = 'Subject: {}\n\n{}'.format(subject, text)
								
							server = smtplib.SMTP('smtp.gmail.com',587)
							server.starttls()
							server.login(fromaddr, password)
							server.sendmail(fromaddr, message)
							server.quit()
							print(start + " Bildirim Bana da Gönderildi, Teşekkürler <3")
							sys.exit()
				else:
					time.sleep(0.3)
					print(start + " İyi şanslar :) " + start)
					sys.exit()

		elif "@hotmail" in fromaddr or "@outlook" in fromaddr or "@live" in fromaddr:
			time.sleep(5)
			debug = False
			if debug:
				print(msg.as_string())
			else:
				server = smtplib.SMTP('smtp.live.com',587)
				server.starttls()
				server.login(fromaddr, password)
				text = msg.as_string()
				server.sendmail(fromaddr, toaddr, text)
				server.quit()
				print(alert + "Email Gönderildi" + alert)
				
				PermCheck = open("Permission.txt", "r")
				Check = PermCheck.read()
				PermCheck.close()
				if "No" in Check:
					os.system("clear")
				else:
					while True:
						if "Yes" in Check:
							subject = "Phishmailer Sender"
							text = "Email Sent With PhishMailer"
							message = 'Subject: {}\n\n{}'.format(subject, text)
							
							server = smtplib.SMTP('smtp.live.com',587)
							server.starttls()
							server.login(fromaddr, password)
							server.sendmail(fromaddr, message)
							server.quit()
							print(start + " Bildirim Bana da Gönderildi, Teşekkürler <3")
							sys.exit()
							
		elif "@yahoo" in fromaddr:
			time.sleep(5)
			debug = False
			if debug:
				print(msg.as_string())
			else:
				server = smtplib.SMTP_SSL('smtp.mail.yahoo.com',465)
				server.starttls()
				server.login(fromaddr, password)
				text = msg.as_string()
				server.sendmail(fromaddr, toaddr, text)
				server.quit()
				print(alert + "Email Gönderildi" + alert)
				
				PermCheck = open("Permission.txt", "r")
				Check = PermCheck.read()
				PermCheck.close()
				if "No" in Check:
					os.system("clear")
				else:
					while True:
						if "Yes" in Check:
							subject = "Phishmailer Sender"
							text = "Email Sent With PhishMailer"
							message = 'Subject: {}\n\n{}'.format(subject, text)
							
							server = smtplib.SMTP('smtp.yahoo.com',587)
							server.starttls()
							server.login(fromaddr, password)
							server.sendmail(fromaddr, MyMail, message)
							server.quit()
							print(start + " Bildirim Bana da Gönderildi, Teşekkürler <3")
							sys.exit()

		else:
			print(alert + " Henüz o e-posta sağlayıcısını desteklemiyor")
			print(question + " Özel SMTP Yakında Gelecek")


def GETSIZE():
	file_path = 'emails.txt'
# check if size of file is 0
	if os.stat(file_path).st_size == 0:
		print(alert + " Kayıtlı E-postanız Yok :(")
		print(question + " Birini Kaydetmek İster misiniz? Y veya N: ")
		answer = input(green + "\nroot@phishmailer/Mailer/:~ " + white)
		
		if answer == "Y" or answer == "y":
			accountsave()
		
		else: 
			MailingMain()
	else:
		pick()


def MailerMenu():
	print(green + """
	 __^__                                                        __^__
	( ___ )------------------------------------------------------( ___ )
	 | / |                                                        | \ |
	 | / |+------------)PhishMailer BaitMailer V2.0(-------------+| \ |
	 |___|                                                        |___|
	(_____)------------------------------------------------------(_____) """)
	print("")
	print(numbering(1) + white + " E-postayı Bir Kez Kullanın")
	print(numbering(2) + white + " Kayıtlı E-postaları Kullan")
	print(numbering(99) + red + " Çıkış")
	
	Pick = int(input(green + "\nroot@phishmailer/Mailer/:~ " + white))
	
	if Pick == 1:
		MailingMain()
	
	elif Pick == 2:
		GETSIZE() #pick()
		
	elif Pick == 99:
		sys.exit()
	
	else:
		os.system("clear")
		print(alert + " Geçersiz Seçenek, Tekrar Deneyin!")
