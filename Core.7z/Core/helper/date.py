import time
import sys

def monthName(num):
	if num == 1:
		return "Ocak"
	elif num == 2:
		return "Şubat"
	elif num == 3:
		return "Mart"
	elif num == 4:
		return "Nisan"
	elif num == 5:
		return "Mayıs"
	elif num == 6:
		return "Haziran"
	elif num == 7:
		return "Temmuz"
	elif num == 8:
		return "Ağustos"
	elif num == 9:
		return "Eylül"
	elif num == 10:
		return "Ekim"
	elif num == 11:
		return "Kasım"
	elif num == 12:
		return "Aralık"
	else:
		print(" Hata")
		time.sleep(1)
		print(" Çıkış")
		sys.exit()